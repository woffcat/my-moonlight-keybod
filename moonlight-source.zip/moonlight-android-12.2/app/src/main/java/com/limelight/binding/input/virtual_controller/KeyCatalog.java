package com.limelight.binding.input.virtual_controller;

import android.view.KeyEvent;

import com.limelight.nvstream.input.ControllerPacket;

import java.util.ArrayList;
import java.util.List;

/**
 * List of keyboard keys (Android key codes) and gamepad buttons that the user can
 * pick when adding a new button to the on-screen controls.
 */
public class KeyCatalog {
    public static final class Entry {
        public final String label;
        public final int code;

        Entry(String label, int code) {
            this.label = label;
            this.code = code;
        }
    }

    public static final List<Entry> KEYS = new ArrayList<>();
    public static final List<Entry> PAD_BUTTONS = new ArrayList<>();

    private static void key(String label, int code) {
        KEYS.add(new Entry(label, code));
    }

    static {
        for (int i = 0; i < 26; i++) {
            key(String.valueOf((char) ('A' + i)), KeyEvent.KEYCODE_A + i);
        }
        for (int i = 0; i <= 9; i++) {
            key(String.valueOf(i), KeyEvent.KEYCODE_0 + i);
        }
        for (int i = 1; i <= 12; i++) {
            key("F" + i, KeyEvent.KEYCODE_F1 + (i - 1));
        }

        key("Esc", KeyEvent.KEYCODE_ESCAPE);
        key("Tab", KeyEvent.KEYCODE_TAB);
        key("Enter", KeyEvent.KEYCODE_ENTER);
        key("Space", KeyEvent.KEYCODE_SPACE);
        key("Bksp", KeyEvent.KEYCODE_DEL);
        key("Del", KeyEvent.KEYCODE_FORWARD_DEL);
        key("Ins", KeyEvent.KEYCODE_INSERT);
        key("Home", KeyEvent.KEYCODE_MOVE_HOME);
        key("End", KeyEvent.KEYCODE_MOVE_END);
        key("PgUp", KeyEvent.KEYCODE_PAGE_UP);
        key("PgDn", KeyEvent.KEYCODE_PAGE_DOWN);
        key("Caps", KeyEvent.KEYCODE_CAPS_LOCK);

        key("Shift", KeyEvent.KEYCODE_SHIFT_LEFT);
        key("Ctrl", KeyEvent.KEYCODE_CTRL_LEFT);
        key("Alt", KeyEvent.KEYCODE_ALT_LEFT);
        key("Win", KeyEvent.KEYCODE_META_LEFT);

        key("\u2191", KeyEvent.KEYCODE_DPAD_UP);
        key("\u2193", KeyEvent.KEYCODE_DPAD_DOWN);
        key("\u2190", KeyEvent.KEYCODE_DPAD_LEFT);
        key("\u2192", KeyEvent.KEYCODE_DPAD_RIGHT);

        key("-", KeyEvent.KEYCODE_MINUS);
        key("=", KeyEvent.KEYCODE_EQUALS);
        key("[", KeyEvent.KEYCODE_LEFT_BRACKET);
        key("]", KeyEvent.KEYCODE_RIGHT_BRACKET);
        key("\\", KeyEvent.KEYCODE_BACKSLASH);
        key(";", KeyEvent.KEYCODE_SEMICOLON);
        key("'", KeyEvent.KEYCODE_APOSTROPHE);
        key(",", KeyEvent.KEYCODE_COMMA);
        key(".", KeyEvent.KEYCODE_PERIOD);
        key("/", KeyEvent.KEYCODE_SLASH);
        key("`", KeyEvent.KEYCODE_GRAVE);

        PAD_BUTTONS.add(new Entry("A", ControllerPacket.A_FLAG));
        PAD_BUTTONS.add(new Entry("B", ControllerPacket.B_FLAG));
        PAD_BUTTONS.add(new Entry("X", ControllerPacket.X_FLAG));
        PAD_BUTTONS.add(new Entry("Y", ControllerPacket.Y_FLAG));
        PAD_BUTTONS.add(new Entry("LB", ControllerPacket.LB_FLAG));
        PAD_BUTTONS.add(new Entry("RB", ControllerPacket.RB_FLAG));
        PAD_BUTTONS.add(new Entry("L3", ControllerPacket.LS_CLK_FLAG));
        PAD_BUTTONS.add(new Entry("R3", ControllerPacket.RS_CLK_FLAG));
        PAD_BUTTONS.add(new Entry("START", ControllerPacket.PLAY_FLAG));
        PAD_BUTTONS.add(new Entry("BACK", ControllerPacket.BACK_FLAG));
        PAD_BUTTONS.add(new Entry("GUIDE", ControllerPacket.SPECIAL_BUTTON_FLAG));
        PAD_BUTTONS.add(new Entry("\u2191", ControllerPacket.UP_FLAG));
        PAD_BUTTONS.add(new Entry("\u2193", ControllerPacket.DOWN_FLAG));
        PAD_BUTTONS.add(new Entry("\u2190", ControllerPacket.LEFT_FLAG));
        PAD_BUTTONS.add(new Entry("\u2192", ControllerPacket.RIGHT_FLAG));
    }

    public static String[] labels(List<Entry> list) {
        String[] out = new String[list.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = list.get(i).label;
        }
        return out;
    }
}
