/**
 * Created by Karim Mreisi.
 */

package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.limelight.LimeLog;
import com.limelight.R;
import com.limelight.binding.input.ControllerHandler;

import java.util.ArrayList;
import java.util.List;

public class VirtualController {
    public static class ControllerInputContext {
        public short inputMap = 0x0000;
        public byte leftTrigger = 0x00;
        public byte rightTrigger = 0x00;
        public short rightStickX = 0x0000;
        public short rightStickY = 0x0000;
        public short leftStickX = 0x0000;
        public short leftStickY = 0x0000;
    }

    public enum ControllerMode {
        Active,
        MoveButtons,
        ResizeButtons
    }

    /**
     * Callbacks into the game activity for things the overlay can't do by itself.
     */
    public interface Host {
        void sendKey(int androidKeyCode, boolean down);
        void toggleTouchMode();
    }

    private static final boolean _PRINT_DEBUG_INFORMATION = false;

    private Host host;

    private final ControllerHandler controllerHandler;
    private final Context context;
    private final Handler handler;

    private final Runnable delayedRetransmitRunnable = new Runnable() {
        @Override
        public void run() {
            sendControllerInputContextInternal();
        }
    };

    private FrameLayout frame_layout = null;

    ControllerMode currentMode = ControllerMode.Active;
    ControllerInputContext inputContext = new ControllerInputContext();

    private Button buttonConfigure = null;
    private Button buttonKeyboard = null;
    private Button buttonTouchMode = null;
    private Button buttonAddKey = null;
    private Button buttonAddPad = null;
    private OnScreenKeyboard keyboardPanel = null;
    private boolean keyboardVisible = false;
    private boolean overlaysHidden = false;

    private List<VirtualControllerElement> elements = new ArrayList<>();

    public VirtualController(final ControllerHandler controllerHandler, FrameLayout layout, final Context context) {
        this.controllerHandler = controllerHandler;
        this.frame_layout = layout;
        this.context = context;
        this.handler = new Handler(Looper.getMainLooper());

        buttonConfigure = new Button(context);
        buttonConfigure.setAlpha(0.25f);
        buttonConfigure.setFocusable(false);
        buttonConfigure.setBackgroundResource(R.drawable.ic_settings);
        buttonConfigure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message;

                if (currentMode == ControllerMode.Active){
                    currentMode = ControllerMode.MoveButtons;
                    message = "Entering configuration mode (Move buttons)";
                } else if (currentMode == ControllerMode.MoveButtons) {
                    currentMode = ControllerMode.ResizeButtons;
                    message = "Entering configuration mode (Resize buttons)";
                } else {
                    currentMode = ControllerMode.Active;
                    VirtualControllerConfigurationLoader.saveProfile(VirtualController.this, context);
                    message = "Exiting configuration mode";
                }

                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();

                updateConfigButtons();
                buttonConfigure.invalidate();

                for (VirtualControllerElement element : elements) {
                    element.invalidate();
                }
            }
        });

        buttonKeyboard = createToolbarButton("\u2328");
        buttonKeyboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleKeyboardPanel();
            }
        });

        buttonTouchMode = createToolbarButton("\u261D");
        buttonTouchMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (host != null) {
                    host.toggleTouchMode();
                }
            }
        });

        buttonAddKey = createToolbarButton("+ Key");
        buttonAddKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VirtualControllerConfigurationLoader.showAddKeyDialog(VirtualController.this, context);
            }
        });

        buttonAddPad = createToolbarButton("+ Pad");
        buttonAddPad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VirtualControllerConfigurationLoader.showAddPadDialog(VirtualController.this, context);
            }
        });
    }

    private Button createToolbarButton(String text) {
        Button b = new Button(context);
        b.setText(text);
        b.setAllCaps(false);
        b.setAlpha(0.5f);
        b.setFocusable(false);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        return b;
    }

    public void setHost(Host host) {
        this.host = host;
    }

    public void sendKey(int androidKeyCode, boolean down) {
        if (host != null) {
            host.sendKey(androidKeyCode, down);
        }
    }

    private void updateConfigButtons() {
        int vis = (currentMode == ControllerMode.Active || overlaysHidden) ? View.GONE : View.VISIBLE;
        buttonAddKey.setVisibility(vis);
        buttonAddPad.setVisibility(vis);
    }

    private void toggleKeyboardPanel() {
        keyboardVisible = !keyboardVisible;
        if (!keyboardVisible && keyboardPanel != null) {
            keyboardPanel.releaseAllModifiers();
        }
        if (keyboardPanel != null) {
            keyboardPanel.setVisibility(keyboardVisible ? View.VISIBLE : View.GONE);
        }
    }

    /**
     * Removes an element from the screen without touching saved preferences.
     */
    public void removeElement(VirtualControllerElement element) {
        frame_layout.removeView(element);
        elements.remove(element);
    }

    /**
     * Removes an element and remembers that the user deleted it.
     */
    public void deleteElement(VirtualControllerElement element) {
        removeElement(element);
        VirtualControllerConfigurationLoader.onElementDeleted(context, element.elementId);
    }

    Handler getHandler() {
        return handler;
    }

    public void hide() {
        overlaysHidden = true;
        for (VirtualControllerElement element : elements) {
            element.setVisibility(View.INVISIBLE);
        }

        buttonConfigure.setVisibility(View.INVISIBLE);
        buttonKeyboard.setVisibility(View.INVISIBLE);
        buttonTouchMode.setVisibility(View.INVISIBLE);
        if (keyboardPanel != null) {
            keyboardPanel.setVisibility(View.GONE);
        }
        updateConfigButtons();
    }

    public void show() {
        overlaysHidden = false;
        for (VirtualControllerElement element : elements) {
            element.setVisibility(View.VISIBLE);
        }

        buttonConfigure.setVisibility(View.VISIBLE);
        buttonKeyboard.setVisibility(View.VISIBLE);
        buttonTouchMode.setVisibility(View.VISIBLE);
        if (keyboardPanel != null) {
            keyboardPanel.setVisibility(keyboardVisible ? View.VISIBLE : View.GONE);
        }
        updateConfigButtons();
    }

    public void removeElements() {
        for (VirtualControllerElement element : elements) {
            frame_layout.removeView(element);
        }
        elements.clear();

        frame_layout.removeView(buttonConfigure);
        frame_layout.removeView(buttonKeyboard);
        frame_layout.removeView(buttonTouchMode);
        frame_layout.removeView(buttonAddKey);
        frame_layout.removeView(buttonAddPad);
        if (keyboardPanel != null) {
            frame_layout.removeView(keyboardPanel);
            keyboardPanel = null;
        }
    }

    public void setOpacity(int opacity) {
        for (VirtualControllerElement element : elements) {
            element.setOpacity(opacity);
        }
    }


    public void addElement(VirtualControllerElement element, int x, int y, int width, int height) {
        elements.add(element);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(width, height);
        layoutParams.setMargins(x, y, 0, 0);

        frame_layout.addView(element, layoutParams);
    }

    public List<VirtualControllerElement> getElements() {
        return elements;
    }

    private static final void _DBG(String text) {
        if (_PRINT_DEBUG_INFORMATION) {
            LimeLog.info("VirtualController: " + text);
        }
    }

    public void refreshLayout() {
        removeElements();

        DisplayMetrics screen = context.getResources().getDisplayMetrics();

        int buttonSize = (int)(screen.heightPixels*0.06f);
        int gap = 10;

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(buttonSize, buttonSize);
        params.leftMargin = 15;
        params.topMargin = 15;
        frame_layout.addView(buttonConfigure, params);

        // Keyboard toggle
        params = new FrameLayout.LayoutParams(buttonSize, buttonSize);
        params.leftMargin = 15 + (buttonSize + gap);
        params.topMargin = 15;
        frame_layout.addView(buttonKeyboard, params);

        // Touch mode toggle (direct touch <-> trackpad)
        params = new FrameLayout.LayoutParams(buttonSize, buttonSize);
        params.leftMargin = 15 + 2 * (buttonSize + gap);
        params.topMargin = 15;
        frame_layout.addView(buttonTouchMode, params);

        // Toolbar shown only while configuring: add a keyboard key / add a gamepad button
        params = new FrameLayout.LayoutParams(buttonSize * 2, buttonSize);
        params.leftMargin = 15 + 3 * (buttonSize + gap);
        params.topMargin = 15;
        frame_layout.addView(buttonAddKey, params);

        params = new FrameLayout.LayoutParams(buttonSize * 2, buttonSize);
        params.leftMargin = 15 + 3 * (buttonSize + gap) + buttonSize * 2 + gap;
        params.topMargin = 15;
        frame_layout.addView(buttonAddPad, params);

        // Start with the default layout
        VirtualControllerConfigurationLoader.createDefaultLayout(this, context);

        // Remove default elements the user deleted, then add the user's own buttons
        VirtualControllerConfigurationLoader.removeDeletedElements(this, context);
        VirtualControllerConfigurationLoader.loadCustomElements(this, context);

        // Apply user preferences onto the layout
        VirtualControllerConfigurationLoader.loadFromPreferences(this, context);

        // On-screen keyboard panel (kept above the buttons, hidden until toggled)
        keyboardPanel = new OnScreenKeyboard(context, this);
        FrameLayout.LayoutParams kbParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                (int) (screen.heightPixels * 0.5f),
                Gravity.BOTTOM);
        frame_layout.addView(keyboardPanel, kbParams);
        keyboardPanel.setVisibility(keyboardVisible && !overlaysHidden ? View.VISIBLE : View.GONE);

        updateConfigButtons();
    }

    public ControllerMode getControllerMode() {
        return currentMode;
    }

    public ControllerInputContext getControllerInputContext() {
        return inputContext;
    }

    private void sendControllerInputContextInternal() {
        _DBG("INPUT_MAP + " + inputContext.inputMap);
        _DBG("LEFT_TRIGGER " + inputContext.leftTrigger);
        _DBG("RIGHT_TRIGGER " + inputContext.rightTrigger);
        _DBG("LEFT STICK X: " + inputContext.leftStickX + " Y: " + inputContext.leftStickY);
        _DBG("RIGHT STICK X: " + inputContext.rightStickX + " Y: " + inputContext.rightStickY);

        if (controllerHandler != null) {
            controllerHandler.reportOscState(
                    inputContext.inputMap,
                    inputContext.leftStickX,
                    inputContext.leftStickY,
                    inputContext.rightStickX,
                    inputContext.rightStickY,
                    inputContext.leftTrigger,
                    inputContext.rightTrigger
            );
        }
    }

    void sendControllerInputContext() {
        // Cancel retransmissions of prior gamepad inputs
        handler.removeCallbacks(delayedRetransmitRunnable);

        sendControllerInputContextInternal();

        // HACK: GFE sometimes discards gamepad packets when they are received
        // very shortly after another. This can be critical if an axis zeroing packet
        // is lost and causes an analog stick to get stuck. To avoid this, we retransmit
        // the gamepad state a few times unless another input event happens before then.
        handler.postDelayed(delayedRetransmitRunnable, 25);
        handler.postDelayed(delayedRetransmitRunnable, 50);
        handler.postDelayed(delayedRetransmitRunnable, 75);
    }
}
