package com.limelight.binding.input.virtual_controller;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * All dialogs of the virtual controls: main menu, button settings, key / mouse / icon pickers,
 * theme & layout chooser with preview, and the profile manager. They work the same inside a
 * game and in the stand-alone layout editor.
 */
public final class ControlsUi {
    private ControlsUi() {
    }

    // Thai when the device language is Thai, English otherwise
    static String t(String en, String th) {
        return "th".equals(Locale.getDefault().getLanguage()) ? th : en;
    }

    private static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    interface Callback<T> {
        void done(T value);
    }

    // =============================================================================
    // Main menu
    // =============================================================================

    public static void showMainMenu(final VirtualController vc) {
        final Context ctx = vc.getContext();
        final boolean joy = VirtualControllerConfigurationLoader.hasJoystick(ctx);
        final boolean low = vc.isLowPerformance();

        final List<String> items = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();

        items.add(t("Profiles", "\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c") + "  (" + ProfileStore.activeName(ctx) + ")");
        actions.add(new Runnable() {
            @Override
            public void run() {
                showProfiles(vc);
            }
        });

        items.add(t("Theme & layout", "\u0e18\u0e35\u0e21\u0e41\u0e25\u0e30\u0e40\u0e25\u0e22\u0e4c\u0e40\u0e2d\u0e32\u0e15\u0e4c"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                showThemeAndLayout(vc);
            }
        });

        items.add(vc.isConfiguring()
                ? t("Finish arranging buttons", "\u0e08\u0e1a\u0e01\u0e32\u0e23\u0e08\u0e31\u0e14\u0e1b\u0e38\u0e48\u0e21")
                : t("Arrange buttons", "\u0e08\u0e31\u0e14\u0e27\u0e32\u0e07\u0e1b\u0e38\u0e48\u0e21"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                if (vc.isConfiguring()) {
                    vc.exitConfigMode();
                }
                else {
                    vc.enterConfigMode();
                }
            }
        });

        items.add(t("Add keyboard / mouse button", "\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e1b\u0e38\u0e48\u0e21\u0e04\u0e35\u0e22\u0e4c\u0e1a\u0e2d\u0e23\u0e4c\u0e14/\u0e40\u0e21\u0e32\u0e2a\u0e4c"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                showAddKeyFlow(vc);
            }
        });

        items.add(t("Add gamepad button", "\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e1b\u0e38\u0e48\u0e21\u0e08\u0e2d\u0e22\u0e40\u0e01\u0e21"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                showAddPadDialog(vc);
            }
        });

        items.add(t("WASD joystick: ", "\u0e08\u0e2d\u0e22\u0e2a\u0e15\u0e34\u0e4a\u0e01 WASD: ")
                + (joy ? t("ON (tap to remove)", "\u0e40\u0e1b\u0e34\u0e14\u0e2d\u0e22\u0e39\u0e48 (\u0e41\u0e15\u0e30\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e1b\u0e34\u0e14)")
                : t("OFF (tap to add)", "\u0e1b\u0e34\u0e14\u0e2d\u0e22\u0e39\u0e48 (\u0e41\u0e15\u0e30\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e40\u0e1b\u0e34\u0e14)")));
        actions.add(new Runnable() {
            @Override
            public void run() {
                vc.setJoystickEnabled(!joy);
                if (!joy) {
                    vc.enterConfigMode();
                }
            }
        });

        items.add(t("Low performance mode: ", "\u0e42\u0e2b\u0e21\u0e14\u0e1b\u0e23\u0e30\u0e2b\u0e22\u0e31\u0e14\u0e17\u0e23\u0e31\u0e1e\u0e22\u0e32\u0e01\u0e23: ")
                + (low ? t("ON", "\u0e40\u0e1b\u0e34\u0e14") : t("OFF", "\u0e1b\u0e34\u0e14")));
        actions.add(new Runnable() {
            @Override
            public void run() {
                vc.setLowPerformance(!low);
                Toast.makeText(ctx, !low
                        ? t("Low performance mode on: no glow or animations", "\u0e40\u0e1b\u0e34\u0e14\u0e42\u0e2b\u0e21\u0e14\u0e1b\u0e23\u0e30\u0e2b\u0e22\u0e31\u0e14: \u0e1b\u0e34\u0e14\u0e41\u0e2d\u0e19\u0e34\u0e40\u0e21\u0e0a\u0e31\u0e19\u0e41\u0e25\u0e30\u0e40\u0e2d\u0e1f\u0e40\u0e1f\u0e01\u0e15\u0e4c\u0e40\u0e23\u0e37\u0e2d\u0e07\u0e41\u0e2a\u0e07")
                        : t("Low performance mode off", "\u0e1b\u0e34\u0e14\u0e42\u0e2b\u0e21\u0e14\u0e1b\u0e23\u0e30\u0e2b\u0e22\u0e31\u0e14\u0e17\u0e23\u0e31\u0e1e\u0e22\u0e32\u0e01\u0e23"),
                        Toast.LENGTH_SHORT).show();
            }
        });

        new AlertDialog.Builder(ctx)
                .setTitle(t("Virtual controls", "\u0e1b\u0e38\u0e48\u0e21\u0e04\u0e27\u0e1a\u0e04\u0e38\u0e21\u0e1a\u0e19\u0e08\u0e2d"))
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        actions.get(which).run();
                    }
                })
                .setNegativeButton(t("Close", "\u0e1b\u0e34\u0e14"), null)
                .show();
    }

    // =============================================================================
    // Adding buttons
    // =============================================================================

    public static void showAddKeyFlow(final VirtualController vc) {
        showBindingDialog(vc.getContext(), new Binding(), new Callback<Binding>() {
            @Override
            public void done(Binding value) {
                if (!value.isEmpty()) {
                    vc.addKeyButton(value);
                    vc.enterConfigMode();
                }
            }
        });
    }

    public static void showAddPadDialog(final VirtualController vc) {
        final List<KeyCatalog.Entry> buttons = KeyCatalog.PAD_BUTTONS;
        new AlertDialog.Builder(vc.getContext())
                .setTitle(t("Add gamepad button", "\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e1b\u0e38\u0e48\u0e21\u0e08\u0e2d\u0e22\u0e40\u0e01\u0e21"))
                .setItems(KeyCatalog.labels(buttons), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        vc.addPadButton(buttons.get(which).code);
                        vc.enterConfigMode();
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }

    // =============================================================================
    // Key / mouse binding editor
    // =============================================================================

    private static boolean isModifier(int code) {
        return code == android.view.KeyEvent.KEYCODE_SHIFT_LEFT || code == android.view.KeyEvent.KEYCODE_CTRL_LEFT
                || code == android.view.KeyEvent.KEYCODE_ALT_LEFT || code == android.view.KeyEvent.KEYCODE_META_LEFT;
    }

    private static boolean contains(int[] array, int value) {
        for (int v : array) {
            if (v == value) return true;
        }
        return false;
    }

    /** Dialog to edit any number of keyboard keys and mouse inputs for one button. */
    static void showBindingDialog(final Context ctx, final Binding initial, final Callback<Binding> callback) {
        final Binding working = initial.copy();

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(ctx, 16);
        root.setPadding(pad, pad, pad, 0);

        final TextView summary = new TextView(ctx);
        summary.setTextSize(22f);
        summary.setGravity(Gravity.CENTER);
        summary.setPadding(0, 0, 0, dp(ctx, 12));
        root.addView(summary);

        final Runnable refresh = new Runnable() {
            @Override
            public void run() {
                summary.setText(working.isEmpty()
                        ? t("(nothing assigned)", "(\u0e22\u0e31\u0e07\u0e44\u0e21\u0e48\u0e21\u0e35\u0e01\u0e32\u0e23\u0e01\u0e33\u0e2b\u0e19\u0e14)")
                        : working.describe());
            }
        };
        refresh.run();

        Button keys = new Button(ctx);
        keys.setText(t("Keyboard keys\u2026", "\u0e04\u0e35\u0e22\u0e4c\u0e1a\u0e2d\u0e23\u0e4c\u0e14\u2026"));
        keys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickKeys(ctx, working, refresh);
            }
        });
        root.addView(keys);

        Button mouse = new Button(ctx);
        mouse.setText(t("Mouse buttons / wheel\u2026", "\u0e40\u0e21\u0e32\u0e2a\u0e4c / \u0e25\u0e39\u0e01\u0e01\u0e25\u0e34\u0e49\u0e07\u2026"));
        mouse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickMouse(ctx, working, refresh);
            }
        });
        root.addView(mouse);

        Button clear = new Button(ctx);
        clear.setText(t("Clear", "\u0e25\u0e49\u0e32\u0e07"));
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                working.keys = new int[0];
                working.mouse = new int[0];
                refresh.run();
            }
        });
        root.addView(clear);

        TextView hint = new TextView(ctx);
        hint.setText(t("All selected keys and mouse buttons are pressed together.",
                "\u0e04\u0e35\u0e22\u0e4c\u0e41\u0e25\u0e30\u0e1b\u0e38\u0e48\u0e21\u0e40\u0e21\u0e32\u0e2a\u0e4c\u0e17\u0e35\u0e48\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e08\u0e30\u0e16\u0e39\u0e01\u0e01\u0e14\u0e1e\u0e23\u0e49\u0e2d\u0e21\u0e01\u0e31\u0e19"));
        hint.setTextSize(12f);
        hint.setPadding(0, dp(ctx, 8), 0, 0);
        root.addView(hint);

        ScrollView scroll = new ScrollView(ctx);
        scroll.addView(root);

        new AlertDialog.Builder(ctx)
                .setTitle(t("Keys & mouse", "\u0e04\u0e35\u0e22\u0e4c\u0e41\u0e25\u0e30\u0e40\u0e21\u0e32\u0e2a\u0e4c"))
                .setView(scroll)
                .setPositiveButton(t("OK", "\u0e15\u0e01\u0e25\u0e07"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        callback.done(working);
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }

    private static void pickKeys(Context ctx, final Binding working, final Runnable changed) {
        final List<KeyCatalog.Entry> catalog = KeyCatalog.KEYS;
        final boolean[] checked = new boolean[catalog.size()];
        for (int i = 0; i < checked.length; i++) {
            checked[i] = contains(working.keys, catalog.get(i).code);
        }

        new AlertDialog.Builder(ctx)
                .setTitle(t("Keyboard keys", "\u0e04\u0e35\u0e22\u0e4c\u0e1a\u0e2d\u0e23\u0e4c\u0e14"))
                .setMultiChoiceItems(KeyCatalog.labels(catalog), checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton(t("OK", "\u0e15\u0e01\u0e25\u0e07"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Modifiers go first so "Ctrl + C" has Ctrl held down when C is pressed
                        List<Integer> out = new ArrayList<>();
                        for (int i = 0; i < checked.length; i++) {
                            if (checked[i] && isModifier(catalog.get(i).code)) out.add(catalog.get(i).code);
                        }
                        for (int i = 0; i < checked.length; i++) {
                            if (checked[i] && !isModifier(catalog.get(i).code)) out.add(catalog.get(i).code);
                        }
                        working.keys = new int[out.size()];
                        for (int i = 0; i < out.size(); i++) working.keys[i] = out.get(i);
                        changed.run();
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }

    private static void pickMouse(Context ctx, final Binding working, final Runnable changed) {
        final int[] codes = {Binding.MOUSE_LEFT, Binding.MOUSE_RIGHT, Binding.MOUSE_MIDDLE,
                Binding.MOUSE_X1, Binding.MOUSE_X2, Binding.WHEEL_UP, Binding.WHEEL_DOWN};
        final String[] names = {
                t("Left click", "\u0e04\u0e25\u0e34\u0e01\u0e0b\u0e49\u0e32\u0e22"),
                t("Right click", "\u0e04\u0e25\u0e34\u0e01\u0e02\u0e27\u0e32"),
                t("Middle click (wheel button)", "\u0e04\u0e25\u0e34\u0e01\u0e01\u0e25\u0e32\u0e07 (\u0e01\u0e14\u0e25\u0e39\u0e01\u0e01\u0e25\u0e34\u0e49\u0e07)"),
                t("Mouse 4 (back)", "\u0e40\u0e21\u0e32\u0e2a\u0e4c 4 (\u0e22\u0e49\u0e2d\u0e19\u0e01\u0e25\u0e31\u0e1a)"),
                t("Mouse 5 (forward)", "\u0e40\u0e21\u0e32\u0e2a\u0e4c 5 (\u0e44\u0e1b\u0e02\u0e49\u0e32\u0e07\u0e2b\u0e19\u0e49\u0e32)"),
                t("Wheel up", "\u0e40\u0e25\u0e37\u0e48\u0e2d\u0e19\u0e25\u0e39\u0e01\u0e01\u0e25\u0e34\u0e49\u0e07\u0e02\u0e36\u0e49\u0e19"),
                t("Wheel down", "\u0e40\u0e25\u0e37\u0e48\u0e2d\u0e19\u0e25\u0e39\u0e01\u0e01\u0e25\u0e34\u0e49\u0e07\u0e25\u0e07")
        };
        final boolean[] checked = new boolean[codes.length];
        for (int i = 0; i < codes.length; i++) {
            checked[i] = contains(working.mouse, codes[i]);
        }

        new AlertDialog.Builder(ctx)
                .setTitle(t("Mouse", "\u0e40\u0e21\u0e32\u0e2a\u0e4c"))
                .setMultiChoiceItems(names, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton(t("OK", "\u0e15\u0e01\u0e25\u0e07"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        List<Integer> out = new ArrayList<>();
                        for (int i = 0; i < codes.length; i++) {
                            if (checked[i]) out.add(codes[i]);
                        }
                        working.mouse = new int[out.size()];
                        for (int i = 0; i < out.size(); i++) working.mouse[i] = out.get(i);
                        changed.run();
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }

    // =============================================================================
    // Icon picker
    // =============================================================================

    static void showIconPicker(final Context ctx, final Callback<String> callback) {
        final int cell = dp(ctx, 48);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx, 8), dp(ctx, 8), dp(ctx, 8), dp(ctx, 8));

        ScrollView scroll = new ScrollView(ctx);
        scroll.addView(root);

        final AlertDialog dialog = new AlertDialog.Builder(ctx)
                .setTitle(t("Choose an icon", "\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e44\u0e2d\u0e04\u0e2d\u0e19"))
                .setView(scroll)
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .create();

        Button none = new Button(ctx);
        none.setText(t("No icon (use text)", "\u0e44\u0e21\u0e48\u0e43\u0e0a\u0e49\u0e44\u0e2d\u0e04\u0e2d\u0e19 (\u0e43\u0e0a\u0e49\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21)"));
        none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                callback.done("");
            }
        });
        root.addView(none);

        // Number of columns that fit the dialog width
        int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
        int columns = Math.max(4, Math.min(10, (int) (screenW * 0.7f / cell)));

        for (IconLibrary.Category category : IconLibrary.CATEGORIES) {
            List<IconLibrary.Icon> icons = IconLibrary.visibleIcons(category);
            if (icons.isEmpty()) {
                continue;
            }

            TextView header = new TextView(ctx);
            header.setText(category.name);
            header.setTextSize(14f);
            header.setTypeface(null, android.graphics.Typeface.BOLD);
            header.setPadding(dp(ctx, 4), dp(ctx, 12), 0, dp(ctx, 4));
            root.addView(header);

            GridLayout grid = new GridLayout(ctx);
            grid.setColumnCount(columns);
            for (final IconLibrary.Icon icon : icons) {
                final TextView cellView = new TextView(ctx);
                cellView.setText(icon.glyph);
                cellView.setTextSize(24f);
                cellView.setGravity(Gravity.CENTER);
                cellView.setContentDescription(icon.name);
                cellView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        callback.done(icon.glyph);
                    }
                });
                cellView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        Toast.makeText(ctx, icon.name, Toast.LENGTH_SHORT).show();
                        return true;
                    }
                });
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = cell;
                lp.height = cell;
                grid.addView(cellView, lp);
            }
            root.addView(grid);
        }

        dialog.show();
    }

    // =============================================================================
    // Button settings (long press while arranging)
    // =============================================================================

    private static final int[] SWATCHES = {
            0, 0xFFFFFF, 0xE53935, 0xFB8C00, 0xFDD835, 0x43A047, 0x00ACC1, 0x1E88E5, 0x8E24AA, 0xEC407A, 0x9E9E9E
    };

    private static void styleChip(Button b, boolean selected) {
        b.setAlpha(selected ? 1f : 0.55f);
        b.setTypeface(null, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
    }

    public static void showElementDialog(final VirtualController vc, final VirtualControllerElement element) {
        final Context ctx = vc.getContext();
        final ControlStyle original = element.getStyle().copy();
        final ControlStyle working = original.copy();
        final Binding[] workingBinding = new Binding[1];
        final boolean hasBinding = element.supportsBinding() && element instanceof KeyButton;
        if (hasBinding) {
            workingBinding[0] = ((KeyButton) element).getBinding().copy();
        }

        final LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(ctx, 16);
        root.setPadding(pad, dp(ctx, 8), pad, 0);

        // ---- binding ----
        final Button bindingButton = new Button(ctx);
        if (hasBinding) {
            final Runnable updateBindingText = new Runnable() {
                @Override
                public void run() {
                    Binding b = workingBinding[0];
                    bindingButton.setText(t("Keys & mouse: ", "\u0e04\u0e35\u0e22\u0e4c\u0e41\u0e25\u0e30\u0e40\u0e21\u0e32\u0e2a\u0e4c: ")
                            + (b.isEmpty() ? t("(none)", "(\u0e44\u0e21\u0e48\u0e21\u0e35)") : b.describe()));
                }
            };
            updateBindingText.run();
            bindingButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showBindingDialog(ctx, workingBinding[0], new Callback<Binding>() {
                        @Override
                        public void done(Binding value) {
                            workingBinding[0] = value;
                            updateBindingText.run();
                            ((KeyButton) element).setBinding(value);
                        }
                    });
                }
            });
            root.addView(bindingButton);
        }

        final Runnable applyLive = new Runnable() {
            @Override
            public void run() {
                element.setStyle(working.copy());
            }
        };

        // ---- shape + icon + label ----
        if (element.supportsShapeAndIcon()) {
            addSectionTitle(ctx, root, t("Shape", "\u0e23\u0e39\u0e1b\u0e17\u0e23\u0e07"));
            HorizontalScrollView shapeScroll = new HorizontalScrollView(ctx);
            LinearLayout shapeRow = new LinearLayout(ctx);
            shapeRow.setOrientation(LinearLayout.HORIZONTAL);
            shapeScroll.addView(shapeRow);
            final List<Button> chips = new ArrayList<>();
            final String[] shapeNames = {
                    t("Theme", "\u0e15\u0e32\u0e21\u0e18\u0e35\u0e21"), t("Circle", "\u0e27\u0e07\u0e01\u0e25\u0e21"),
                    t("Rounded", "\u0e21\u0e38\u0e21\u0e21\u0e19"), t("Square", "\u0e2a\u0e35\u0e48\u0e40\u0e2b\u0e25\u0e35\u0e48\u0e22\u0e21"),
                    t("Pill", "\u0e41\u0e04\u0e1b\u0e0b\u0e39\u0e25"), t("Hexagon", "\u0e2b\u0e01\u0e40\u0e2b\u0e25\u0e35\u0e48\u0e22\u0e21"),
                    t("Diamond", "\u0e40\u0e1e\u0e0a\u0e23")
            };
            for (int i = 0; i < shapeNames.length; i++) {
                final int shapeValue = i == 0 ? ControlStyle.SHAPE_DEFAULT : i - 1;
                Button chip = new Button(ctx);
                chip.setText(shapeNames[i]);
                chip.setAllCaps(false);
                styleChip(chip, working.shape == shapeValue);
                chip.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        working.shape = shapeValue;
                        for (int k = 0; k < chips.size(); k++) {
                            styleChip(chips.get(k), (k == 0 ? ControlStyle.SHAPE_DEFAULT : k - 1) == working.shape);
                        }
                        applyLive.run();
                    }
                });
                chips.add(chip);
                shapeRow.addView(chip);
            }
            root.addView(shapeScroll);

            addSectionTitle(ctx, root, t("Icon & text", "\u0e44\u0e2d\u0e04\u0e2d\u0e19\u0e41\u0e25\u0e30\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21"));
            LinearLayout iconRow = new LinearLayout(ctx);
            iconRow.setOrientation(LinearLayout.HORIZONTAL);
            final Button iconButton = new Button(ctx);
            iconButton.setTextSize(22f);
            iconButton.setText(working.icon.isEmpty() ? t("Icon\u2026", "\u0e44\u0e2d\u0e04\u0e2d\u0e19\u2026") : working.icon);
            iconButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showIconPicker(ctx, new Callback<String>() {
                        @Override
                        public void done(String glyph) {
                            working.icon = glyph;
                            iconButton.setText(glyph.isEmpty() ? t("Icon\u2026", "\u0e44\u0e2d\u0e04\u0e2d\u0e19\u2026") : glyph);
                            applyLive.run();
                        }
                    });
                }
            });
            iconRow.addView(iconButton);

            final EditText labelEdit = new EditText(ctx);
            labelEdit.setHint(t("Label (empty = automatic)", "\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21 (\u0e27\u0e48\u0e32\u0e07 = \u0e2d\u0e31\u0e15\u0e42\u0e19\u0e21\u0e31\u0e15\u0e34)"));
            labelEdit.setInputType(InputType.TYPE_CLASS_TEXT);
            labelEdit.setSingleLine(true);
            labelEdit.setText(working.label != null ? working.label : "");
            labelEdit.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(android.text.Editable s) {
                    working.label = s.length() == 0 ? null : s.toString();
                    applyLive.run();
                }
            });
            iconRow.addView(labelEdit, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            root.addView(iconRow);
        }

        // ---- colour ----
        addSectionTitle(ctx, root, t("Color", "\u0e2a\u0e35"));
        HorizontalScrollView colorScroll = new HorizontalScrollView(ctx);
        final LinearLayout colorRow = new LinearLayout(ctx);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        colorScroll.addView(colorRow);
        final List<View> swatchViews = new ArrayList<>();
        for (final int rgb : SWATCHES) {
            View sw = new View(ctx);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(ctx, 34), dp(ctx, 34));
            lp.setMargins(dp(ctx, 4), dp(ctx, 4), dp(ctx, 4), dp(ctx, 4));
            sw.setLayoutParams(lp);
            sw.setTag(rgb);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    working.color = rgb;
                    for (View s : swatchViews) {
                        paintSwatch(ctx, s, (Integer) s.getTag() == working.color);
                    }
                    applyLive.run();
                }
            });
            paintSwatch(ctx, sw, rgb == working.color);
            swatchViews.add(sw);
            colorRow.addView(sw);
        }
        root.addView(colorScroll);

        // ---- opacity ----
        addSectionTitle(ctx, root, t("Opacity of this button", "\u0e04\u0e27\u0e32\u0e21\u0e17\u0e36\u0e1a\u0e02\u0e2d\u0e07\u0e1b\u0e38\u0e48\u0e21\u0e19\u0e35\u0e49"));
        root.addView(makeSeek(ctx, 10, 100, working.alphaPct, new Callback<Integer>() {
            @Override
            public void done(Integer value) {
                working.alphaPct = value;
                applyLive.run();
            }
        }));

        // ---- joystick sensitivity ----
        if (element.isJoystick()) {
            addSectionTitle(ctx, root, t("Sensitivity (higher = reacts sooner)", "\u0e04\u0e27\u0e32\u0e21\u0e44\u0e27 (\u0e22\u0e34\u0e48\u0e07\u0e2a\u0e39\u0e07\u0e22\u0e34\u0e48\u0e07\u0e15\u0e2d\u0e1a\u0e2a\u0e19\u0e2d\u0e07\u0e40\u0e23\u0e47\u0e27)"));
            root.addView(makeSeek(ctx, 0, 100, working.sensitivity, new Callback<Integer>() {
                @Override
                public void done(Integer value) {
                    working.sensitivity = value;
                    applyLive.run();
                }
            }));
        }

        TextView sizeHint = new TextView(ctx);
        sizeHint.setText(t("Tip: use the cog button to switch between Move and Resize.",
                "\u0e40\u0e04\u0e25\u0e47\u0e14\u0e25\u0e31\u0e1a: \u0e01\u0e14\u0e1b\u0e38\u0e48\u0e21\u0e1f\u0e31\u0e19\u0e40\u0e1f\u0e37\u0e2d\u0e07\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e2a\u0e25\u0e31\u0e1a\u0e23\u0e30\u0e2b\u0e27\u0e48\u0e32\u0e07\u0e22\u0e49\u0e32\u0e22\u0e41\u0e25\u0e30\u0e1b\u0e23\u0e31\u0e1a\u0e02\u0e19\u0e32\u0e14"));
        sizeHint.setTextSize(12f);
        sizeHint.setPadding(0, dp(ctx, 12), 0, dp(ctx, 8));
        root.addView(sizeHint);

        ScrollView scroll = new ScrollView(ctx);
        scroll.addView(root);

        final boolean isCustom = element.getElementId() >= VirtualControllerElement.EID_CUSTOM_BASE;
        final AlertDialog dialog = new AlertDialog.Builder(ctx)
                .setTitle(t("Button settings", "\u0e15\u0e31\u0e49\u0e07\u0e04\u0e48\u0e32\u0e1b\u0e38\u0e48\u0e21"))
                .setView(scroll)
                .setPositiveButton(t("Save", "\u0e1a\u0e31\u0e19\u0e17\u0e36\u0e01"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        element.setStyle(working.copy());
                        VirtualControllerConfigurationLoader.saveStyle(ctx, element.getElementId(), working);
                        if (hasBinding) {
                            VirtualControllerConfigurationLoader.saveBinding(ctx, element.getElementId(), workingBinding[0]);
                        }
                        vc.notifyLayoutChanged();
                    }
                })
                .setNeutralButton(isCustom ? t("Delete", "\u0e25\u0e1a") : t("Hide", "\u0e0b\u0e48\u0e2d\u0e19"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        confirmDelete(vc, element, isCustom, original);
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        element.setStyle(original);
                        if (hasBinding) {
                            ((KeyButton) element).setBinding(initialBinding(ctx, element));
                        }
                    }
                })
                .create();
        dialog.setCanceledOnTouchOutside(false);
        // Back button counts as Cancel: undo the live preview
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface d) {
                element.setStyle(original);
                if (hasBinding) {
                    ((KeyButton) element).setBinding(initialBinding(ctx, element));
                }
            }
        });
        dialog.show();
    }

    private static Binding initialBinding(Context ctx, VirtualControllerElement element) {
        // Re-read the saved binding so a cancelled edit leaves nothing behind
        try {
            org.json.JSONArray array = new org.json.JSONArray(ProfileStore.prefs(ctx)
                    .getString(VirtualControllerConfigurationLoader.CUSTOM_ELEMENTS_KEY, "[]"));
            for (int i = 0; i < array.length(); i++) {
                org.json.JSONObject o = array.getJSONObject(i);
                if (o.getInt("id") == element.getElementId()) {
                    return Binding.fromJson(o);
                }
            }
        } catch (org.json.JSONException e) {
            e.printStackTrace();
        }
        return ((KeyButton) element).getBinding();
    }

    private static void confirmDelete(final VirtualController vc, final VirtualControllerElement element,
                                      boolean custom, final ControlStyle original) {
        Context ctx = vc.getContext();
        new AlertDialog.Builder(ctx)
                .setTitle(custom ? t("Delete this button?", "\u0e25\u0e1a\u0e1b\u0e38\u0e48\u0e21\u0e19\u0e35\u0e49?") : t("Hide this button?", "\u0e0b\u0e48\u0e2d\u0e19\u0e1b\u0e38\u0e48\u0e21\u0e19\u0e35\u0e49?"))
                .setMessage(custom
                        ? t("The button is removed from this profile.", "\u0e1b\u0e38\u0e48\u0e21\u0e19\u0e35\u0e49\u0e08\u0e30\u0e16\u0e39\u0e01\u0e25\u0e1a\u0e2d\u0e2d\u0e01\u0e08\u0e32\u0e01\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c\u0e19\u0e35\u0e49")
                        : t("Pick the Gamepad layout under Theme & layout to get it back.", "\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e40\u0e25\u0e22\u0e4c\u0e40\u0e2d\u0e32\u0e15\u0e4c\u0e08\u0e2d\u0e22\u0e40\u0e01\u0e21\u0e43\u0e19\u0e18\u0e35\u0e21\u0e41\u0e25\u0e30\u0e40\u0e25\u0e22\u0e4c\u0e40\u0e2d\u0e32\u0e15\u0e4c\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e19\u0e33\u0e01\u0e25\u0e31\u0e1a\u0e21\u0e32"))
                .setPositiveButton(custom ? t("Delete", "\u0e25\u0e1a") : t("Hide", "\u0e0b\u0e48\u0e2d\u0e19"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        vc.deleteElement(element);
                        vc.notifyLayoutChanged();
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        element.setStyle(original);
                    }
                })
                .show();
    }

    private static void addSectionTitle(Context ctx, LinearLayout root, String title) {
        TextView tv = new TextView(ctx);
        tv.setText(title);
        tv.setTextSize(13f);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(0, dp(ctx, 12), 0, dp(ctx, 2));
        root.addView(tv);
    }

    private static void paintSwatch(Context ctx, View v, boolean selected) {
        int rgb = (Integer) v.getTag();
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        if (rgb == 0) {
            d.setColor(0xFF444444);
        }
        else {
            d.setColor(0xFF000000 | rgb);
        }
        d.setStroke(dp(ctx, selected ? 3 : 1), selected ? Color.WHITE : 0x88FFFFFF);
        v.setBackground(d);
        if (v instanceof TextView) {
            return;
        }
    }

    private static SeekBar makeSeek(Context ctx, final int min, int max, int value, final Callback<Integer> cb) {
        SeekBar bar = new SeekBar(ctx);
        bar.setMax(max - min);
        bar.setProgress(Math.max(0, Math.min(max, value)) - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    cb.done(progress + min);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        return bar;
    }

    // =============================================================================
    // Theme & layout chooser (with preview)
    // =============================================================================

    public static void showThemeAndLayout(final VirtualController vc) {
        final Context ctx = vc.getContext();

        final ControlTheme[] selectedTheme = {VirtualControllerConfigurationLoader.getTheme(ctx)};
        // null = keep the current layout
        final LayoutPresets.Preset[] selectedPreset = {null};
        final boolean[] lowPerf = {vc.isLowPerformance()};

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(ctx, 16);
        root.setPadding(pad, dp(ctx, 8), pad, 0);

        final ThemePreviewView preview = new ThemePreviewView(ctx);
        preview.setContent(selectedTheme[0], null, lowPerf[0]);
        root.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addSectionTitle(ctx, root, t("Theme", "\u0e18\u0e35\u0e21"));
        HorizontalScrollView themeScroll = new HorizontalScrollView(ctx);
        LinearLayout themeRow = new LinearLayout(ctx);
        themeScroll.addView(themeRow);
        final List<Button> themeChips = new ArrayList<>();
        for (final ControlTheme theme : ControlTheme.ALL) {
            Button chip = new Button(ctx);
            chip.setAllCaps(false);
            chip.setText(theme.name);
            styleChip(chip, theme == selectedTheme[0]);
            chip.setTag(theme);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedTheme[0] = theme;
                    for (Button b : themeChips) {
                        styleChip(b, b.getTag() == theme);
                    }
                    preview.setContent(theme, selectedPreset[0], lowPerf[0]);
                }
            });
            themeChips.add(chip);
            themeRow.addView(chip);
        }
        root.addView(themeScroll);

        addSectionTitle(ctx, root, t("Layout", "\u0e40\u0e25\u0e22\u0e4c\u0e40\u0e2d\u0e32\u0e15\u0e4c"));
        HorizontalScrollView layoutScroll = new HorizontalScrollView(ctx);
        LinearLayout layoutRow = new LinearLayout(ctx);
        layoutScroll.addView(layoutRow);
        final List<Button> layoutChips = new ArrayList<>();

        Button keep = new Button(ctx);
        keep.setAllCaps(false);
        keep.setText(t("Keep current", "\u0e04\u0e07\u0e02\u0e2d\u0e07\u0e40\u0e14\u0e34\u0e21"));
        styleChip(keep, true);
        keep.setTag(null);
        layoutChips.add(keep);
        layoutRow.addView(keep);
        keep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPreset[0] = null;
                for (Button b : layoutChips) {
                    styleChip(b, b.getTag() == null);
                }
                preview.setContent(selectedTheme[0], null, lowPerf[0]);
            }
        });

        for (final LayoutPresets.Preset preset : LayoutPresets.ALL) {
            Button chip = new Button(ctx);
            chip.setAllCaps(false);
            chip.setText(t(preset.name, preset.nameTh));
            styleChip(chip, false);
            chip.setTag(preset);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedPreset[0] = preset;
                    for (Button b : layoutChips) {
                        styleChip(b, b.getTag() == preset);
                    }
                    preview.setContent(selectedTheme[0], preset, lowPerf[0]);
                }
            });
            layoutChips.add(chip);
            layoutRow.addView(chip);
        }
        root.addView(layoutScroll);

        CheckBox low = new CheckBox(ctx);
        low.setText(t("Low performance mode (no glow, no animations)",
                "\u0e42\u0e2b\u0e21\u0e14\u0e1b\u0e23\u0e30\u0e2b\u0e22\u0e31\u0e14\u0e17\u0e23\u0e31\u0e1e\u0e22\u0e32\u0e01\u0e23 (\u0e44\u0e21\u0e48\u0e21\u0e35\u0e41\u0e2a\u0e07\u0e40\u0e23\u0e37\u0e2d\u0e07/\u0e41\u0e2d\u0e19\u0e34\u0e40\u0e21\u0e0a\u0e31\u0e19)"));
        low.setChecked(lowPerf[0]);
        low.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                lowPerf[0] = isChecked;
                preview.setContent(selectedTheme[0], selectedPreset[0], isChecked);
            }
        });
        low.setPadding(0, dp(ctx, 8), 0, dp(ctx, 8));
        root.addView(low);

        ScrollView scroll = new ScrollView(ctx);
        scroll.addView(root);

        new AlertDialog.Builder(ctx)
                .setTitle(t("Theme & layout", "\u0e18\u0e35\u0e21\u0e41\u0e25\u0e30\u0e40\u0e25\u0e22\u0e4c\u0e40\u0e2d\u0e32\u0e15\u0e4c"))
                .setView(scroll)
                .setPositiveButton(t("Apply", "\u0e43\u0e0a\u0e49\u0e07\u0e32\u0e19"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (lowPerf[0] != vc.isLowPerformance()) {
                            vc.setLowPerformance(lowPerf[0]);
                        }
                        if (selectedPreset[0] != null) {
                            confirmApplyPreset(vc, selectedTheme[0], selectedPreset[0]);
                        }
                        else {
                            vc.applyTheme(selectedTheme[0]);
                        }
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }

    private static void confirmApplyPreset(final VirtualController vc, final ControlTheme theme,
                                           final LayoutPresets.Preset preset) {
        final Context ctx = vc.getContext();
        new AlertDialog.Builder(ctx)
                .setTitle(t("Replace layout?", "\u0e41\u0e17\u0e19\u0e17\u0e35\u0e48\u0e40\u0e25\u0e22\u0e4c\u0e40\u0e2d\u0e32\u0e15\u0e4c?"))
                .setMessage(t("The buttons of profile \"" + ProfileStore.activeName(ctx) + "\" are replaced by \"" + preset.name + "\". "
                                + "You can still move and edit every button afterwards.",
                        "\u0e1b\u0e38\u0e48\u0e21\u0e43\u0e19\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c \"" + ProfileStore.activeName(ctx) + "\" \u0e08\u0e30\u0e16\u0e39\u0e01\u0e41\u0e17\u0e19\u0e17\u0e35\u0e48\u0e14\u0e49\u0e27\u0e22 \"" + preset.nameTh + "\" "
                                + "\u0e41\u0e25\u0e30\u0e22\u0e31\u0e07\u0e41\u0e01\u0e49\u0e44\u0e02\u0e17\u0e38\u0e01\u0e1b\u0e38\u0e48\u0e21\u0e44\u0e14\u0e49\u0e20\u0e32\u0e22\u0e2b\u0e25\u0e31\u0e07"))
                .setPositiveButton(t("Replace", "\u0e41\u0e17\u0e19\u0e17\u0e35\u0e48"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        LayoutPresets.apply(ctx, preset);
                        VirtualControllerConfigurationLoader.saveTheme(ctx, theme);
                        vc.refreshLayout();
                        vc.notifyLayoutChanged();
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }

    // =============================================================================
    // Profiles
    // =============================================================================

    public static void showProfiles(final VirtualController vc) {
        final Context ctx = vc.getContext();
        final List<ProfileStore.Profile> profiles = ProfileStore.list(ctx);
        final String active = ProfileStore.activeId(ctx);
        final String gameKey = vc.getHost() != null ? vc.getHost().getGameKey() : null;
        final String gameProfile = ProfileStore.gameProfile(ctx, gameKey);

        List<String> names = new ArrayList<>();
        for (ProfileStore.Profile p : profiles) {
            String line = p.name;
            if (p.id.equals(active)) line = "\u2713 " + line;
            if (p.id.equals(gameProfile)) line += "  (" + t("this game", "\u0e40\u0e01\u0e21\u0e19\u0e35\u0e49") + ")";
            names.add(line);
        }
        names.add("\uff0b " + t("New profile", "\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c\u0e43\u0e2b\u0e21\u0e48"));

        new AlertDialog.Builder(ctx)
                .setTitle(t("Profiles", "\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c"))
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == profiles.size()) {
                            askNewProfile(vc);
                        }
                        else {
                            showProfileActions(vc, profiles.get(which));
                        }
                    }
                })
                .setNegativeButton(t("Close", "\u0e1b\u0e34\u0e14"), null)
                .show();
    }

    private static void askName(final Context ctx, String title, String initial, final Callback<String> cb) {
        final EditText edit = new EditText(ctx);
        edit.setSingleLine(true);
        edit.setText(initial);
        edit.setSelection(initial.length());
        new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setView(edit)
                .setPositiveButton(t("OK", "\u0e15\u0e01\u0e25\u0e07"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String name = edit.getText().toString().trim();
                        if (!name.isEmpty()) {
                            cb.done(name);
                        }
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }

    private static void askNewProfile(final VirtualController vc) {
        final Context ctx = vc.getContext();
        askName(ctx, t("New profile", "\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c\u0e43\u0e2b\u0e21\u0e48"),
                t("My profile", "\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19"), new Callback<String>() {
                    @Override
                    public void done(String name) {
                        // Start from the stock gamepad layout, then let the user pick a layout / theme
                        ProfileStore.Profile p = ProfileStore.create(ctx, name, null);
                        switchTo(vc, p.id, false);
                        showThemeAndLayout(vc);
                    }
                });
    }

    private static void switchTo(VirtualController vc, String profileId, boolean toast) {
        Context ctx = vc.getContext();
        if (vc.isConfiguring()) {
            vc.saveLayout();
        }
        ProfileStore.setActive(ctx, profileId);
        vc.refreshLayout();
        vc.notifyLayoutChanged();
        if (toast) {
            Toast.makeText(ctx, t("Profile: ", "\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c: ") + ProfileStore.activeName(ctx), Toast.LENGTH_SHORT).show();
        }
    }

    private static void showProfileActions(final VirtualController vc, final ProfileStore.Profile profile) {
        final Context ctx = vc.getContext();
        final String gameKey = vc.getHost() != null ? vc.getHost().getGameKey() : null;
        final boolean isDefault = ProfileStore.DEFAULT_ID.equals(profile.id);

        final List<String> items = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();

        items.add(t("Use for all games", "\u0e43\u0e0a\u0e49\u0e01\u0e31\u0e1a\u0e17\u0e38\u0e01\u0e40\u0e01\u0e21"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                if (gameKey != null) {
                    ProfileStore.setGameProfile(ctx, gameKey, null);
                }
                ProfileStore.setGeneralDefault(ctx, profile.id);
                switchTo(vc, profile.id, true);
            }
        });

        if (gameKey != null) {
            items.add(t("Use for this game only", "\u0e43\u0e0a\u0e49\u0e01\u0e31\u0e1a\u0e40\u0e01\u0e21\u0e19\u0e35\u0e49\u0e40\u0e17\u0e48\u0e32\u0e19\u0e31\u0e49\u0e19"));
            actions.add(new Runnable() {
                @Override
                public void run() {
                    ProfileStore.setGameProfile(ctx, gameKey, profile.id);
                    switchTo(vc, profile.id, true);
                }
            });
        }

        items.add(t("Edit layout", "\u0e41\u0e01\u0e49\u0e44\u0e02\u0e40\u0e25\u0e22\u0e4c\u0e40\u0e2d\u0e32\u0e15\u0e4c"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                switchTo(vc, profile.id, false);
                vc.enterConfigMode();
            }
        });

        items.add(t("Rename", "\u0e40\u0e1b\u0e25\u0e35\u0e48\u0e22\u0e19\u0e0a\u0e37\u0e48\u0e2d"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                askName(ctx, t("Rename profile", "\u0e40\u0e1b\u0e25\u0e35\u0e48\u0e22\u0e19\u0e0a\u0e37\u0e48\u0e2d\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c"), profile.name, new Callback<String>() {
                    @Override
                    public void done(String name) {
                        ProfileStore.rename(ctx, profile.id, name);
                        showProfiles(vc);
                    }
                });
            }
        });

        items.add(t("Duplicate", "\u0e17\u0e33\u0e2a\u0e33\u0e40\u0e19\u0e32"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                // Make sure the latest positions are in the copy
                if (profile.id.equals(ProfileStore.activeId(ctx))) {
                    vc.saveLayout();
                }
                ProfileStore.create(ctx, t("Copy of ", "\u0e2a\u0e33\u0e40\u0e19\u0e32 ") + profile.name, profile.id);
                showProfiles(vc);
            }
        });

        items.add(isDefault ? t("Reset to stock layout", "\u0e23\u0e35\u0e40\u0e0b\u0e47\u0e15\u0e40\u0e1b\u0e47\u0e19\u0e04\u0e48\u0e32\u0e40\u0e23\u0e34\u0e48\u0e21\u0e15\u0e49\u0e19") : t("Delete", "\u0e25\u0e1a"));
        actions.add(new Runnable() {
            @Override
            public void run() {
                new AlertDialog.Builder(ctx)
                        .setTitle(isDefault ? t("Reset this profile?", "\u0e23\u0e35\u0e40\u0e0b\u0e47\u0e15\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c\u0e19\u0e35\u0e49?") : t("Delete this profile?", "\u0e25\u0e1a\u0e42\u0e1b\u0e23\u0e44\u0e1f\u0e25\u0e4c\u0e19\u0e35\u0e49?"))
                        .setMessage(profile.name)
                        .setPositiveButton(isDefault ? t("Reset", "\u0e23\u0e35\u0e40\u0e0b\u0e47\u0e15") : t("Delete", "\u0e25\u0e1a"), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                boolean wasActive = profile.id.equals(ProfileStore.activeId(ctx));
                                ProfileStore.delete(ctx, profile.id);
                                if (wasActive || isDefault) {
                                    vc.refreshLayout();
                                    vc.notifyLayoutChanged();
                                }
                                showProfiles(vc);
                            }
                        })
                        .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                        .show();
            }
        });

        new AlertDialog.Builder(ctx)
                .setTitle(profile.name)
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        actions.get(which).run();
                    }
                })
                .setNegativeButton(t("Back", "\u0e01\u0e25\u0e31\u0e1a"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showProfiles(vc);
                    }
                })
                .show();
    }

    // =============================================================================
    // Per-game profile chooser (used from the game list, outside of a stream)
    // =============================================================================

    public static void showGameProfileChooser(final Context ctx, final String gameKey, final String gameName) {
        final List<ProfileStore.Profile> profiles = ProfileStore.list(ctx);
        final String current = ProfileStore.gameProfile(ctx, gameKey);

        final String[] names = new String[profiles.size() + 1];
        names[0] = (current == null ? "\u2713 " : "") + t("Same as other games (default)", "\u0e40\u0e2b\u0e21\u0e37\u0e2d\u0e19\u0e40\u0e01\u0e21\u0e2d\u0e37\u0e48\u0e19 (\u0e04\u0e48\u0e32\u0e40\u0e23\u0e34\u0e48\u0e21\u0e15\u0e49\u0e19)");
        for (int i = 0; i < profiles.size(); i++) {
            ProfileStore.Profile p = profiles.get(i);
            names[i + 1] = (p.id.equals(current) ? "\u2713 " : "") + p.name;
        }

        new AlertDialog.Builder(ctx)
                .setTitle(t("Controls for ", "\u0e1b\u0e38\u0e48\u0e21\u0e04\u0e27\u0e1a\u0e04\u0e38\u0e21\u0e2a\u0e33\u0e2b\u0e23\u0e31\u0e1a ") + gameName)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            ProfileStore.setGameProfile(ctx, gameKey, null);
                        }
                        else {
                            ProfileStore.setGameProfile(ctx, gameKey, profiles.get(which - 1).id);
                        }
                        Toast.makeText(ctx, t("Saved", "\u0e1a\u0e31\u0e19\u0e17\u0e36\u0e01\u0e41\u0e25\u0e49\u0e27"), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(t("Cancel", "\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01"), null)
                .show();
    }
}
