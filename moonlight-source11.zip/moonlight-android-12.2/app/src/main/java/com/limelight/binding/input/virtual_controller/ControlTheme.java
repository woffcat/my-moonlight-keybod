package com.limelight.binding.input.virtual_controller;

import android.graphics.Path;
import android.graphics.RectF;

/**
 * Visual theme for the virtual controls. Themes are plain data so drawing them is cheap:
 * a button is one filled path, one stroked path and (optionally) one wider translucent stroke
 * as a glow. There are no blurs or shadow layers.
 */
public final class ControlTheme {
    public final String id;
    public final String name;
    public final int fill;
    public final int fillPressed;
    public final int stroke;
    public final int strokePressed;
    public final float strokeDp;
    public final int text;
    /** 0 = no glow */
    public final int glow;
    public final int shape;
    public final int knob;
    public final int knobStroke;
    /** Colour used for legacy gamepad elements that only draw outlines. */
    public final int accent;
    public final int accentPressed;
    public final boolean faceColors;

    private ControlTheme(String id, String name, int fill, int fillPressed, int stroke, int strokePressed,
                         float strokeDp, int text, int glow, int shape, int knob, int knobStroke,
                         int accent, int accentPressed, boolean faceColors) {
        this.id = id;
        this.name = name;
        this.fill = fill;
        this.fillPressed = fillPressed;
        this.stroke = stroke;
        this.strokePressed = strokePressed;
        this.strokeDp = strokeDp;
        this.text = text;
        this.glow = glow;
        this.shape = shape;
        this.knob = knob;
        this.knobStroke = knobStroke;
        this.accent = accent;
        this.accentPressed = accentPressed;
        this.faceColors = faceColors;
    }

    public static final ControlTheme GAMEHUB = new ControlTheme("gamehub", "GameHub",
            0x59000000, 0x73FFFFFF, 0xCCFFFFFF, 0xFFFFFFFF, 1.5f, 0xFFFFFFFF, 0x40FFFFFF,
            ControlStyle.SHAPE_CIRCLE, 0x80FFFFFF, 0xFFFFFFFF, 0xFFE0E0E0, 0xFFFFFFFF, false);

    public static final ControlTheme TRANSPARENT = new ControlTheme("transparent", "Transparent",
            0x00000000, 0x40FFFFFF, 0x80FFFFFF, 0xCCFFFFFF, 1f, 0xCCFFFFFF, 0,
            ControlStyle.SHAPE_CIRCLE, 0x33FFFFFF, 0x99FFFFFF, 0xCCFFFFFF, 0xFFFFFFFF, false);

    public static final ControlTheme MINIMAL = new ControlTheme("minimal", "Minimal",
            0x33000000, 0x80FFFFFF, 0x00000000, 0x00000000, 0f, 0xFFFFFFFF, 0,
            ControlStyle.SHAPE_ROUNDED, 0x66FFFFFF, 0x00000000, 0x99FFFFFF, 0xFFFFFFFF, false);

    public static final ControlTheme MODERN = new ControlTheme("modern", "Modern gaming",
            0xB31B1F2A, 0xE63A86FF, 0xFF4A5368, 0xFF8FB8FF, 1.5f, 0xFFE8ECF4, 0x663A86FF,
            ControlStyle.SHAPE_ROUNDED, 0xCC3A86FF, 0xFF8FB8FF, 0xFF8FB8FF, 0xFF3A86FF, false);

    public static final ControlTheme NEON = new ControlTheme("neon", "Neon",
            0x330A0A14, 0x8000F5D4, 0xFF00F5D4, 0xFFFFFFFF, 2f, 0xFF00F5D4, 0x7000F5D4,
            ControlStyle.SHAPE_CIRCLE, 0x6600F5D4, 0xFF00F5D4, 0xFF00F5D4, 0xFFFF00E5, false);

    public static final ControlTheme CLASSIC = new ControlTheme("classic", "Classic controller",
            0x99333333, 0xCC888888, 0xFFCCCCCC, 0xFFFFFFFF, 2f, 0xFFFFFFFF, 0,
            ControlStyle.SHAPE_CIRCLE, 0xAA555555, 0xFFCCCCCC, 0xFF888888, 0xFF0000FF, true);

    public static final ControlTheme[] ALL = {GAMEHUB, TRANSPARENT, MINIMAL, MODERN, NEON, CLASSIC};

    public static ControlTheme byId(String id) {
        for (ControlTheme t : ALL) {
            if (t.id.equals(id)) {
                return t;
            }
        }
        return GAMEHUB;
    }

    /** Face button colours for the classic theme (A green, B red, X blue, Y yellow). */
    public static int faceColor(int elementId) {
        switch (elementId) {
            case VirtualControllerElement.EID_A: return 0xFF4CAF50;
            case VirtualControllerElement.EID_B: return 0xFFE53935;
            case VirtualControllerElement.EID_X: return 0xFF1E88E5;
            case VirtualControllerElement.EID_Y: return 0xFFFDD835;
            default: return 0;
        }
    }

    public static int resolveShape(ControlStyle style, ControlTheme theme) {
        return style.shape != ControlStyle.SHAPE_DEFAULT ? style.shape : theme.shape;
    }

    /** Builds the outline for a shape inside the given bounds. */
    public static void buildShape(Path p, int shape, float l, float t, float r, float b) {
        p.reset();
        float w = r - l;
        float h = b - t;
        float cx = (l + r) / 2f;
        float cy = (t + b) / 2f;
        float min = Math.min(w, h);
        switch (shape) {
            case ControlStyle.SHAPE_ROUNDED:
                p.addRoundRect(new RectF(l, t, r, b), min * 0.22f, min * 0.22f, Path.Direction.CW);
                break;
            case ControlStyle.SHAPE_SQUARE:
                p.addRect(l, t, r, b, Path.Direction.CW);
                break;
            case ControlStyle.SHAPE_PILL:
                p.addRoundRect(new RectF(l, t, r, b), min / 2f, min / 2f, Path.Direction.CW);
                break;
            case ControlStyle.SHAPE_HEXAGON: {
                float rx = w / 2f;
                float ry = h / 2f;
                for (int i = 0; i < 6; i++) {
                    double a = Math.toRadians(60 * i - 30);
                    float x = cx + (float) Math.cos(a) * rx;
                    float y = cy + (float) Math.sin(a) * ry;
                    if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.close();
                break;
            }
            case ControlStyle.SHAPE_DIAMOND:
                p.moveTo(cx, t);
                p.lineTo(r, cy);
                p.lineTo(cx, b);
                p.lineTo(l, cy);
                p.close();
                break;
            case ControlStyle.SHAPE_CIRCLE:
            default:
                p.addOval(new RectF(l, t, r, b), Path.Direction.CW);
                break;
        }
    }
}
