package com.limelight.binding.input.virtual_controller;

import android.graphics.Paint;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

/**
 * Large library of icons (emoji / symbols) that can be put on any virtual button.
 * Glyphs the device font cannot draw are filtered out with Paint.hasGlyph() where available.
 */
public final class IconLibrary {
    public static final class Icon {
        public final String name;
        public final String glyph;

        Icon(String name, String glyph) {
            this.name = name;
            this.glyph = glyph;
        }
    }

    public static final class Category {
        public final String name;
        public final List<Icon> icons = new ArrayList<>();

        Category(String name) {
            this.name = name;
        }
    }

    public static final List<Category> CATEGORIES = new ArrayList<>();

    private static Category cat;

    private static void c(String name) {
        cat = new Category(name);
        CATEGORIES.add(cat);
    }

    private static void i(String name, String glyph) {
        cat.icons.add(new Icon(name, glyph));
    }

    static {
        c("Movement");
        i("Run", "\ud83c\udfc3");
        i("Walk", "\ud83d\udeb6");
        i("Sprint", "\ud83d\udca8");
        i("Jump", "\u23eb");
        i("Double jump", "\u23cf\ufe0f");
        i("Crouch", "\ud83d\ude47");
        i("Prone", "\u23ec");
        i("Slide", "\ud83c\udfbf");
        i("Dodge / Roll", "\ud83d\udd04");
        i("Dash", "\u26a1");
        i("Climb", "\ud83e\uddd7");
        i("Swim", "\ud83c\udfca");
        i("Fly", "\ud83d\udd4a\ufe0f");
        i("Parkour", "\ud83e\udd38");
        i("Sneak", "\ud83e\udd77");
        i("Teleport", "\ud83c\udf00");
        i("Ride", "\ud83d\udc0e");
        i("Lean left", "\u21a9\ufe0f");
        i("Lean right", "\u21aa\ufe0f");
        i("Turn around", "\ud83d\udd03");
        c("Directions");
        i("Up", "\u2b06\ufe0f");
        i("Down", "\u2b07\ufe0f");
        i("Left", "\u2b05\ufe0f");
        i("Right", "\u27a1\ufe0f");
        i("Up-left", "\u2196\ufe0f");
        i("Up-right", "\u2197\ufe0f");
        i("Down-left", "\u2199\ufe0f");
        i("Down-right", "\u2198\ufe0f");
        i("Triangle up", "\u25b2");
        i("Triangle down", "\u25bc");
        i("Triangle left", "\u25c0\ufe0f");
        i("Triangle right", "\u25b6\ufe0f");
        i("Fast up", "\ud83d\udd3c");
        i("Fast down", "\ud83d\udd3d");
        i("Up-down", "\u2195\ufe0f");
        i("Left-right", "\u2194\ufe0f");
        i("Four ways", "\u2725");
        i("Target", "\ud83c\udfaf");
        i("Center", "\u23fa\ufe0f");
        i("Compass", "\ud83e\udded");
        c("Combat");
        i("Attack", "\u2694\ufe0f");
        i("Sword", "\ud83d\udde1\ufe0f");
        i("Shoot", "\ud83d\udd2b");
        i("Aim", "\ud83c\udfaf");
        i("Scope", "\ud83d\udd2d");
        i("Reload", "\ud83d\udd04");
        i("Grenade", "\ud83d\udca3");
        i("Shield", "\ud83d\udee1\ufe0f");
        i("Block", "\u270b");
        i("Punch", "\ud83d\udc4a");
        i("Kick", "\ud83e\uddb5");
        i("Bow", "\ud83c\udff9");
        i("Knife", "\ud83d\udd2a");
        i("Hammer", "\ud83d\udd28");
        i("Axe", "\ud83e\ude93");
        i("Fire", "\ud83d\udd25");
        i("Magic", "\u2728");
        i("Spell", "\ud83d\udd2e");
        i("Lightning", "\u26a1");
        i("Explosion", "\ud83d\udca5");
        i("Skull", "\ud83d\udc80");
        i("Ammo", "\ud83d\udd0b");
        i("Swap weapon", "\ud83d\udd01");
        i("Melee", "\ud83e\udd4a");
        i("Special", "\ud83c\udf1f");
        i("Ultimate", "\ud83d\udcab");
        i("Poison", "\u2620\ufe0f");
        i("Ice", "\u2744\ufe0f");
        c("Items");
        i("Inventory", "\ud83c\udf92");
        i("Backpack", "\ud83d\udc5c");
        i("Chest", "\ud83e\uddf0");
        i("Interact", "\ud83d\udc46");
        i("Use", "\ud83d\udd90\ufe0f");
        i("Pick up", "\ud83d\udce5");
        i("Drop", "\ud83d\udce4");
        i("Take", "\ud83e\udd32");
        i("Open door", "\ud83d\udeaa");
        i("Key", "\ud83d\udd11");
        i("Lock", "\ud83d\udd12");
        i("Unlock", "\ud83d\udd13");
        i("Use item", "\ud83e\uddea");
        i("Potion", "\u2697\ufe0f");
        i("Gift", "\ud83c\udf81");
        i("Coin", "\ud83d\udcb0");
        i("Gem", "\ud83d\udc8e");
        i("Book", "\ud83d\udcd6");
        i("Scroll", "\ud83d\udcdc");
        i("Note", "\ud83d\udcdd");
        i("Package", "\ud83d\udce6");
        i("Craft", "\ud83d\udee0\ufe0f");
        i("Build", "\ud83c\udfd7\ufe0f");
        i("Tool", "\ud83d\udd27");
        i("Pickaxe", "\u26cf\ufe0f");
        i("Fishing", "\ud83c\udfa3");
        i("Cook", "\ud83c\udf73");
        i("Food", "\ud83c\udf56");
        i("Drink", "\ud83e\udd64");
        i("Flashlight", "\ud83d\udd26");
        i("Torch", "\ud83d\udd6f\ufe0f");
        i("Trash", "\ud83d\uddd1\ufe0f");
        c("Health & status");
        i("Heal", "\ud83d\udc8a");
        i("Medkit", "\ud83d\udc89");
        i("Heart", "\u2764\ufe0f");
        i("Plus", "\u2795");
        i("Minus", "\u2796");
        i("Shield up", "\ud83d\udee1\ufe0f");
        i("Armor", "\ud83e\udd4b");
        i("Energy", "\ud83d\udd0b");
        i("Stamina", "\ud83d\udcaa");
        i("Sleep", "\ud83d\udca4");
        i("Poison", "\ud83e\uddea");
        i("Buff", "\u2b06\ufe0f");
        i("Debuff", "\u2b07\ufe0f");
        i("Revive", "\ud83d\udc96");
        i("Cure", "\ud83e\ude79");
        i("Water", "\ud83d\udca7");
        c("Interface");
        i("Map", "\ud83d\uddfa\ufe0f");
        i("Menu", "\u2630");
        i("Settings", "\u2699\ufe0f");
        i("Pause", "\u23f8\ufe0f");
        i("Play", "\u25b6\ufe0f");
        i("Stop", "\u23f9\ufe0f");
        i("Record", "\u23fa\ufe0f");
        i("Home", "\ud83c\udfe0");
        i("Search", "\ud83d\udd0d");
        i("Zoom in", "\ud83d\udd0e");
        i("Chat", "\ud83d\udcac");
        i("Voice", "\ud83c\udfa4");
        i("Mute", "\ud83d\udd07");
        i("Volume", "\ud83d\udd0a");
        i("Screenshot", "\ud83d\udcf8");
        i("Scoreboard", "\ud83d\udcca");
        i("Quest", "\u2757");
        i("Question", "\u2753");
        i("Info", "\u2139\ufe0f");
        i("Star", "\u2b50");
        i("Pin", "\ud83d\udccd");
        i("Flag", "\ud83d\udea9");
        i("Bell", "\ud83d\udd14");
        i("Mail", "\u2709\ufe0f");
        i("Check", "\u2714\ufe0f");
        i("Cancel", "\u2716\ufe0f");
        i("OK", "\ud83c\udd97");
        i("Back", "\ud83d\udd19");
        i("Save", "\ud83d\udcbe");
        i("Load", "\ud83d\udcc2");
        i("Phone", "\ud83d\udcf1");
        i("Contacts", "\ud83d\udc65");
        i("Skills", "\ud83c\udf33");
        i("Shop", "\ud83d\uded2");
        c("Camera");
        i("Camera", "\ud83d\udcf7");
        i("Video", "\ud83c\udfa5");
        i("Eye", "\ud83d\udc41\ufe0f");
        i("Look around", "\ud83d\udc40");
        i("Zoom", "\ud83d\udd0d");
        i("Rotate camera", "\ud83d\udd03");
        i("Free look", "\ud83d\udd2d");
        i("First person", "\ud83d\ude42");
        i("Third person", "\ud83e\uddcd");
        i("Lock on", "\ud83c\udfaf");
        i("Photo mode", "\ud83d\udcf8");
        i("Brightness", "\ud83d\udd06");
        i("Night vision", "\ud83c\udf19");
        c("Vehicles");
        i("Car", "\ud83d\ude97");
        i("Sports car", "\ud83c\udfce\ufe0f");
        i("SUV", "\ud83d\ude99");
        i("Truck", "\ud83d\ude9a");
        i("Motorbike", "\ud83c\udfcd\ufe0f");
        i("Bicycle", "\ud83d\udeb2");
        i("Plane", "\u2708\ufe0f");
        i("Helicopter", "\ud83d\ude81");
        i("Boat", "\u26f5");
        i("Speedboat", "\ud83d\udea4");
        i("Train", "\ud83d\ude86");
        i("Rocket", "\ud83d\ude80");
        i("Brake", "\ud83d\uded1");
        i("Handbrake", "\ud83c\udd7f\ufe0f");
        i("Nitro", "\ud83d\ude80");
        i("Horn", "\ud83d\udcef");
        i("Headlights", "\ud83d\udca1");
        i("Fuel", "\u26fd");
        i("Gear up", "\ud83d\udd3c");
        i("Gear down", "\ud83d\udd3d");
        i("Enter vehicle", "\ud83d\ude98");
        i("Exit vehicle", "\ud83d\udeb6");
        i("Traffic", "\ud83d\udea6");
        i("Steer", "\ud83c\udfa1");
        c("Social & emotes");
        i("Emote", "\ud83d\ude00");
        i("Wave", "\ud83d\udc4b");
        i("Dance", "\ud83d\udc83");
        i("Cheer", "\ud83c\udf89");
        i("Laugh", "\ud83d\ude02");
        i("Angry", "\ud83d\ude20");
        i("Thumbs up", "\ud83d\udc4d");
        i("Thumbs down", "\ud83d\udc4e");
        i("Clap", "\ud83d\udc4f");
        i("Ping", "\ud83d\udce2");
        i("Team", "\ud83d\udc65");
        i("Trade", "\ud83e\udd1d");
        i("Gift", "\ud83c\udf81");
        i("Taunt", "\ud83d\ude08");
        c("Controller & misc");
        i("Gamepad", "\ud83c\udfae");
        i("Joystick", "\ud83d\udd79\ufe0f");
        i("Dice", "\ud83c\udfb2");
        i("Trophy", "\ud83c\udfc6");
        i("Medal", "\ud83c\udfc5");
        i("Target", "\ud83c\udfaf");
        i("Puzzle", "\ud83e\udde9");
        i("Music", "\ud83c\udfb5");
        i("Clock", "\u23f0");
        i("Hourglass", "\u23f3");
        i("Sun", "\u2600\ufe0f");
        i("Moon", "\ud83c\udf19");
        i("Cloud", "\u2601\ufe0f");
        i("Rain", "\ud83c\udf27\ufe0f");
        i("Wind", "\ud83c\udf2c\ufe0f");
        i("Tree", "\ud83c\udf32");
        i("Mountain", "\u26f0\ufe0f");
        i("Camp", "\u26fa");
        i("Paw", "\ud83d\udc3e");
        i("Dog", "\ud83d\udc15");
        i("Horse", "\ud83d\udc0e");
        i("Robot", "\ud83e\udd16");
        i("Ghost", "\ud83d\udc7b");
        i("Alien", "\ud83d\udc7d");
        c("Letters & symbols");
        i("Shift", "\u21e7");
        i("Ctrl", "\u2303");
        i("Alt", "\u2325");
        i("Tab", "\u21e5");
        i("Enter", "\u23ce");
        i("Backspace", "\u232b");
        i("Escape", "\u238b");
        i("Space", "\u2423");
        i("Plus sign", "+");
        i("Minus sign", "\u2212");
        i("Cross", "\u2715");
        i("Check mark", "\u2713");
        i("Circle", "\u25cf");
        i("Ring", "\u25cb");
        i("Square", "\u25a0");
        i("Diamond", "\u25c6");
        i("Star symbol", "\u2605");
        i("Heart symbol", "\u2665");
        i("Spade", "\u2660");
        i("Club", "\u2663");
    }

    private static boolean renderable(Paint paint, String glyph) {
        if (Build.VERSION.SDK_INT >= 23) {
            return paint.hasGlyph(glyph);
        }
        return true;
    }

    /** Icons of one category that this device can actually draw. */
    public static List<Icon> visibleIcons(Category category) {
        Paint paint = new Paint();
        List<Icon> out = new ArrayList<>();
        for (Icon icon : category.icons) {
            if (renderable(paint, icon.glyph)) {
                out.add(icon);
            }
        }
        return out;
    }

    public static int totalCount() {
        int n = 0;
        for (Category c : CATEGORIES) {
            n += c.icons.size();
        }
        return n;
    }
}
