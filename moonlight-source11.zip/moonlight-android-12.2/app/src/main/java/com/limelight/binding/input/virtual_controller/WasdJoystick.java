package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;

/**
 * A round, analog-stick looking control that presses the keyboard keys W, A, S and D.
 * Dragging the knob in any direction presses the matching key(s); diagonals press two keys.
 * It never needs a real game controller on the host.
 *
 * Cost per touch event: a hypot and four comparisons. Keys are only sent when the set of
 * pressed keys actually changes.
 */
public class WasdJoystick extends VirtualControllerElement {
    private static final int BIT_W = 1;
    private static final int BIT_A = 2;
    private static final int BIT_S = 4;
    private static final int BIT_D = 8;

    private static final int[] KEY_BITS = {BIT_W, BIT_A, BIT_S, BIT_D};
    private static final int[] KEY_CODES = {
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D
    };
    private static final String[] KEY_LABELS = {"W", "A", "S", "D"};

    // sin(22.5 deg): axis counts as pressed once it is beyond this share of the distance,
    // which gives eight equally sized direction sectors.
    private static final float AXIS_THRESHOLD = 0.3827f;

    private final Paint basePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float centerX, centerY;
    private float outerRadius, knobRadius, maxTravel;
    private float knobDx = 0f, knobDy = 0f;
    private int activeMask = 0;

    public WasdJoystick(VirtualController controller, Context context, int elementId) {
        super(controller, context, elementId);
    }

    @Override
    public boolean usesThemeRendering() {
        return true;
    }

    @Override
    public boolean isJoystick() {
        return true;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        float density = getResources().getDisplayMetrics().density;
        float strokePx = Math.max(1f, theme.strokeDp * density);
        centerX = w / 2f;
        centerY = h / 2f;
        outerRadius = Math.min(w, h) / 2f - strokePx * 3f;
        knobRadius = outerRadius * 0.36f;
        maxTravel = outerRadius - knobRadius;
        super.onSizeChanged(w, h, oldw, oldh);
    }

    @Override
    protected void onStyleChanged() {
        // Radii depend on the theme stroke width
        onSizeChanged(getWidth(), getHeight(), getWidth(), getHeight());
    }

    private int accent() {
        return style.color != 0 ? (0xFF000000 | style.color) : 0;
    }

    @Override
    protected void onElementDraw(Canvas canvas) {
        final boolean pressed = activeMask != 0 || isPressed();
        final boolean configuring = virtualController.getControllerMode() != VirtualController.ControllerMode.Active;
        final float density = getResources().getDisplayMetrics().density;
        final float strokePx = Math.max(0f, theme.strokeDp * density);
        final int accent = accent();

        int baseFill = accent != 0 ? ((0x33 << 24) | (accent & 0xFFFFFF)) : theme.fill;
        int baseStroke = accent != 0 ? accent : (pressed ? theme.strokePressed : theme.stroke);
        int knobFill = accent != 0 ? ((0xAA << 24) | (accent & 0xFFFFFF)) : theme.knob;
        int knobStroke = accent != 0 ? accent : theme.knobStroke;
        float ringWidth = strokePx;
        if (configuring) {
            baseStroke = getDefaultColor();
            ringWidth = Math.max(strokePx, getDefaultStrokeWidth());
        }

        basePaint.setStyle(Paint.Style.FILL);
        basePaint.setColor(baseFill);
        canvas.drawCircle(centerX, centerY, outerRadius, basePaint);

        if (theme.glow != 0 && !virtualController.isLowPerformance() && pressed && !configuring) {
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(Math.max(2f, strokePx) * 3f);
            glowPaint.setColor((theme.glow & 0xFF000000) | ((accent != 0 ? accent : theme.glow) & 0xFFFFFF));
            canvas.drawCircle(centerX, centerY, outerRadius, glowPaint);
        }

        if (ringWidth > 0f && (baseStroke >>> 24) != 0) {
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(ringWidth);
            ringPaint.setColor(baseStroke);
            canvas.drawCircle(centerX, centerY, outerRadius, ringPaint);
        }

        // W / A / S / D hints on the ring; the ones in use are brighter
        hintPaint.setTextAlign(Paint.Align.CENTER);
        hintPaint.setTextSize(outerRadius * 0.20f);
        hintPaint.setFakeBoldText(true);
        final float hintOffset = outerRadius * 0.80f;
        final float textShift = outerRadius * 0.07f;
        for (int i = 0; i < 4; i++) {
            boolean on = (activeMask & KEY_BITS[i]) != 0;
            hintPaint.setColor((on ? 0xFF000000 : 0x99000000) | (theme.text & 0xFFFFFF));
            float hx = centerX + (i == 1 ? -hintOffset : i == 3 ? hintOffset : 0f);
            float hy = centerY + (i == 0 ? -hintOffset : i == 2 ? hintOffset : 0f) + textShift;
            canvas.drawText(KEY_LABELS[i], hx, hy, hintPaint);
        }

        knobPaint.setStyle(Paint.Style.FILL);
        knobPaint.setColor(knobFill);
        canvas.drawCircle(centerX + knobDx, centerY + knobDy, knobRadius, knobPaint);
        if (strokePx > 0f && (knobStroke >>> 24) != 0) {
            knobRingPaint.setStyle(Paint.Style.STROKE);
            knobRingPaint.setStrokeWidth(strokePx);
            knobRingPaint.setColor(knobStroke);
            canvas.drawCircle(centerX + knobDx, centerY + knobDy, knobRadius, knobRingPaint);
        }
    }

    private float deadZone() {
        // sensitivity 0..100 -> dead zone of 45%..5% of the knob travel
        float sens = Math.max(0, Math.min(100, style.sensitivity));
        return maxTravel * (0.45f - 0.40f * sens / 100f);
    }

    private void applyMask(int newMask) {
        if (newMask == activeMask) {
            return;
        }
        int changed = newMask ^ activeMask;

        // Release first, then press, so a direction change never has both keys of an axis down
        for (int i = 0; i < 4; i++) {
            if ((changed & KEY_BITS[i]) != 0 && (newMask & KEY_BITS[i]) == 0) {
                virtualController.sendKey(KEY_CODES[i], false);
            }
        }
        for (int i = 0; i < 4; i++) {
            if ((changed & KEY_BITS[i]) != 0 && (newMask & KEY_BITS[i]) != 0) {
                virtualController.sendKey(KEY_CODES[i], true);
            }
        }
        activeMask = newMask;
    }

    @Override
    public boolean onElementTouchEvent(MotionEvent event) {
        final int action = event.getActionMasked();
        float dx = event.getX() - centerX;
        float dy = event.getY() - centerY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                // Let touches outside of the round base fall through to whatever is underneath
                if (dist > outerRadius) {
                    return false;
                }
                setPressed(true);
                break;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                releaseAll();
                return true;
            default:
                break;
        }

        if (!isPressed()) {
            return false;
        }

        // Keep the knob inside the base
        float kx = dx;
        float ky = dy;
        if (dist > maxTravel && dist > 0f) {
            float s = maxTravel / dist;
            kx = dx * s;
            ky = dy * s;
            dist = maxTravel;
        }
        knobDx = kx;
        knobDy = ky;

        int mask = 0;
        if (dist > deadZone() && dist > 0f) {
            if (ky < -dist * AXIS_THRESHOLD) mask |= BIT_W;
            if (ky > dist * AXIS_THRESHOLD) mask |= BIT_S;
            if (kx < -dist * AXIS_THRESHOLD) mask |= BIT_A;
            if (kx > dist * AXIS_THRESHOLD) mask |= BIT_D;
        }
        applyMask(mask);

        invalidate();
        return true;
    }

    @Override
    public void releaseAll() {
        applyMask(0);
        knobDx = 0f;
        knobDy = 0f;
        if (isPressed()) {
            setPressed(false);
        }
        invalidate();
    }

    @Override
    public void onControllerModeChanged() {
        // Never leave a key stuck down when switching to the layout editor
        releaseAll();
        super.onControllerModeChanged();
    }
}
