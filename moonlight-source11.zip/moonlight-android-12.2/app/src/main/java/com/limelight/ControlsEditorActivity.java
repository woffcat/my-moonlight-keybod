package com.limelight;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.limelight.binding.input.virtual_controller.Binding;
import com.limelight.binding.input.virtual_controller.ProfileStore;
import com.limelight.binding.input.virtual_controller.VirtualController;

/**
 * Stand-alone editor for the virtual controls: lets the user build and style layouts, assign keys,
 * key combinations and mouse buttons, and manage profiles without starting a game.
 * Buttons can be tried out here; the keys they would send are shown at the bottom.
 */
public class ControlsEditorActivity extends Activity {
    private VirtualController controller;
    private TextView testLog;

    private static class GridBackground extends View {
        private final Paint bg = new Paint();
        private final Paint line = new Paint();
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String hint;

        GridBackground(Activity a, String hint) {
            super(a);
            this.hint = hint;
            bg.setColor(0xFF161A22);
            line.setColor(0x14FFFFFF);
            line.setStrokeWidth(1f);
            text.setColor(0x55FFFFFF);
            text.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawRect(0, 0, getWidth(), getHeight(), bg);
            float step = getResources().getDisplayMetrics().density * 32f;
            for (float x = 0; x < getWidth(); x += step) {
                canvas.drawLine(x, 0, x, getHeight(), line);
            }
            for (float y = 0; y < getHeight(); y += step) {
                canvas.drawLine(0, y, getWidth(), y, line);
            }
            text.setTextSize(getResources().getDisplayMetrics().density * 14f);
            canvas.drawText(hint, getWidth() / 2f, getHeight() * 0.5f, text);
        }
    }

    private static boolean thai() {
        return "th".equals(java.util.Locale.getDefault().getLanguage());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root = new FrameLayout(this);
        root.addView(new GridBackground(this, thai()
                ? "\u0e1e\u0e37\u0e49\u0e19\u0e17\u0e35\u0e48\u0e17\u0e14\u0e25\u0e2d\u0e07 \u2014 \u0e25\u0e32\u0e01\u0e1b\u0e38\u0e48\u0e21\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e08\u0e31\u0e14\u0e27\u0e32\u0e07 \u0e01\u0e14\u0e04\u0e49\u0e32\u0e07\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e41\u0e01\u0e49\u0e44\u0e02"
                : "Preview area \u2014 drag buttons to arrange, long-press to edit"),
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        testLog = new TextView(this);
        testLog.setTextColor(0xCCFFFFFF);
        testLog.setTextSize(13f);
        testLog.setGravity(Gravity.CENTER);
        testLog.setPadding(0, 0, 0, 12);
        FrameLayout.LayoutParams logParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(testLog, logParams);

        setContentView(root);

        // The editor always opens the profile used by default for all games
        ProfileStore.setActive(this, ProfileStore.generalDefault(this));

        controller = new VirtualController(null, root, this);
        controller.setEditorMode(true);
        controller.setHost(new VirtualController.Host() {
            @Override
            public void sendKey(int androidKeyCode, boolean down) {
                show((down ? "\u25bc " : "\u25b2 ") + Binding.keyName(androidKeyCode));
            }

            @Override
            public void sendMouseButton(int code, boolean down) {
                show((down ? "\u25bc " : "\u25b2 ") + Binding.mouseName(code));
            }

            @Override
            public void sendScroll(int direction) {
                show(Binding.mouseName(direction > 0 ? Binding.WHEEL_UP : Binding.WHEEL_DOWN));
            }

            @Override
            public void toggleTouchMode() {
            }

            @Override
            public String getGameKey() {
                return null;
            }

            @Override
            public void onLayoutChanged() {
            }
        });

        controller.refreshLayout();
        controller.show();
        controller.enterConfigMode();
        hideSystemUi();
    }

    private void show(String text) {
        testLog.setText((thai() ? "\u0e17\u0e14\u0e2a\u0e2d\u0e1a: " : "Test: ") + text);
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUi();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (controller != null) {
            controller.saveLayout();
            controller.refreshLayout();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Never lose the arrangement, whichever way the user leaves
        if (controller != null) {
            controller.saveLayout();
        }
    }
}
