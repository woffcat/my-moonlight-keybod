package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/**
 * Small static preview of a theme (and optionally a layout preset) drawn inside dialogs.
 * It only draws when something changes, there are no animations.
 */
public class ThemePreviewView extends View {
    private ControlTheme theme = ControlTheme.GAMEHUB;
    private LayoutPresets.Preset preset = null;
    private boolean lowPerf = false;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bg = new Paint();
    private final Path path = new Path();

    public ThemePreviewView(Context context) {
        super(context);
        bg.setColor(0xFF20242C);
        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setContent(ControlTheme theme, LayoutPresets.Preset preset, boolean lowPerf) {
        this.theme = theme;
        this.preset = preset;
        this.lowPerf = lowPerf;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = MeasureSpec.getSize(widthMeasureSpec);
        setMeasuredDimension(w, w * 9 / 16);
    }

    private void drawButton(Canvas c, int shape, float l, float t, float r, float b,
                            boolean pressed, String glyph) {
        final float density = getResources().getDisplayMetrics().density;
        float strokePx = theme.strokeDp * density * 0.7f;
        float inset = Math.max(strokePx, 1f) + (theme.glow != 0 && !lowPerf ? strokePx * 2f : 0f);
        ControlTheme.buildShape(path, shape, l + inset, t + inset, r - inset, b - inset);

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(pressed ? theme.fillPressed : theme.fill);
        c.drawPath(path, fill);

        if (theme.glow != 0 && !lowPerf) {
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeWidth(strokePx * 3f);
            glow.setColor(pressed ? theme.glow : ((theme.glow >>> 24) / 3 << 24) | (theme.glow & 0xFFFFFF));
            c.drawPath(path, glow);
        }
        if (strokePx > 0 && (theme.stroke >>> 24) != 0) {
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(strokePx);
            stroke.setColor(pressed ? theme.strokePressed : theme.stroke);
            c.drawPath(path, stroke);
        }

        text.setColor(theme.text);
        float size = Math.min(r - l, b - t) * 0.42f;
        text.setTextSize(size);
        Paint.FontMetrics fm = text.getFontMetrics();
        c.drawText(glyph, (l + r) / 2f, (t + b) / 2f - (fm.ascent + fm.descent) / 2f, text);
    }

    private void drawJoystick(Canvas c, float cx, float cy, float radius) {
        final float density = getResources().getDisplayMetrics().density;
        float strokePx = theme.strokeDp * density * 0.7f;

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(theme.fill);
        c.drawCircle(cx, cy, radius, fill);
        if (strokePx > 0 && (theme.stroke >>> 24) != 0) {
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(strokePx);
            stroke.setColor(theme.stroke);
            c.drawCircle(cx, cy, radius, stroke);
        }
        fill.setColor(theme.knob);
        c.drawCircle(cx + radius * 0.18f, cy - radius * 0.12f, radius * 0.36f, fill);
        if (strokePx > 0 && (theme.knobStroke >>> 24) != 0) {
            stroke.setColor(theme.knobStroke);
            c.drawCircle(cx + radius * 0.18f, cy - radius * 0.12f, radius * 0.36f, stroke);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final float w = getWidth();
        final float h = getHeight();
        canvas.drawRect(0, 0, w, h, bg);

        if (preset == null) {
            // Generic sample: a joystick and a few buttons
            drawJoystick(canvas, w * 0.20f, h * 0.55f, h * 0.30f);
            float s = h * 0.26f;
            drawButton(canvas, theme.shape, w * 0.62f, h * 0.18f, w * 0.62f + s, h * 0.18f + s, false, "A");
            drawButton(canvas, theme.shape, w * 0.76f, h * 0.38f, w * 0.76f + s, h * 0.38f + s, true, "B");
            drawButton(canvas, ControlStyle.SHAPE_ROUNDED, w * 0.50f, h * 0.55f, w * 0.50f + s, h * 0.55f + s, false, "\u2694\uFE0F");
            return;
        }

        if (preset.keepGamepad) {
            // Rough picture of the stock gamepad layout
            drawJoystick(canvas, w * 0.18f, h * 0.30f, h * 0.20f);
            drawJoystick(canvas, w * 0.76f, h * 0.68f, h * 0.20f);
            float s = h * 0.17f;
            float bx = w * 0.84f;
            float by = h * 0.28f;
            drawButton(canvas, theme.shape, bx - s * 0.5f, by - s * 1.2f, bx + s * 0.5f, by - s * 0.2f, false, "Y");
            drawButton(canvas, theme.shape, bx - s * 1.6f, by - s * 0.1f, bx - s * 0.6f, by + s * 0.9f, false, "X");
            drawButton(canvas, theme.shape, bx + s * 0.6f, by - s * 0.1f, bx + s * 1.6f, by + s * 0.9f, false, "B");
            drawButton(canvas, theme.shape, bx - s * 0.5f, by + s * 1.0f, bx + s * 0.5f, by + s * 2.0f, false, "A");
            drawButton(canvas, ControlStyle.SHAPE_ROUNDED, w * 0.06f, h * 0.62f, w * 0.06f + s * 3f, h * 0.62f + s * 1.0f, false, "\u2190 \u2191 \u2192 \u2193");
            return;
        }

        // Preset: units are 72 = height
        final float unit = h / 72f;
        final float aspectW = h * 16f / 9f; // layout is defined for 16:9
        final float shift = (w - aspectW) / 2f;
        for (LayoutPresets.Item item : preset.items) {
            float size = item.size * unit;
            float width = size * item.widthFactor;
            float left;
            switch (item.anchor) {
                case 'R': left = shift + aspectW - item.x * unit - width; break;
                case 'C': left = w / 2f + item.x * unit - width / 2f; break;
                default: left = shift + item.x * unit; break;
            }
            float top = item.y * unit;
            if ("wasd".equals(item.type)) {
                drawJoystick(canvas, left + size / 2f, top + size / 2f, size / 2f);
                continue;
            }
            String g = item.icon != null && !item.icon.isEmpty() ? item.icon : (item.label != null ? item.label : "");
            drawButton(canvas, theme.shape, left, top, left + width, top + size, false, g);
        }
    }
}
